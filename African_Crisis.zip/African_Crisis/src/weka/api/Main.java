package weka.api;

import java.io.File;

public class Main {

	public static void main (String[] args) {
		
		//Dosyan�n i�indeki t�m dosyalar silinip, sadece kalmas� gereken 3 dosya b�rak�lmas� kodu
		//File folder = folder.listFiles; 
		/*
		String path1 = "/User/Zeynep/eclipse-workspace/African_Crisis/Documents/african_crises.arff";
		String path2 = "/User/Zeynep/eclipse-workspace/African_Crisis/Documents/african_crises2.arff";
		String path3 = "/User/Zeynep/eclipse-workspace/African_Crisis/Documents/african_crises3.arff";
		String path4 = "/User/Zeynep/eclipse-workspace/African_Crisis/Documents/IBk.model";
		String path5 = "/User/Zeynep/eclipse-workspace/African_Crisis/Documents/J48.model";
		String path6 = "/User/Zeynep/eclipse-workspace/African_Crisis/Documents/Logistic.model";
		String path7 = "/User/Zeynep/eclipse-workspace/African_Crisis/Documents/OneR.model";
		String path8 = "/User/Zeynep/eclipse-workspace/African_Crisis/Documents/situationActual.arff";
		String path9 = "/User/Zeynep/eclipse-workspace/African_Crisis/Documents/ZeroR.model";
		*/	
		
		//Ana kullan�c� ekran� a��l�r ve i�lemlere ba�lan�r
		Window1 window = new Window1();
		
	}
	
	
}
